<footer class="page-footer font-small" style="margin-top: 10%;">
    <div class="footer-copyright text-center py-3" style="color: #044d92;">
        <p>&copy; 2019-<?php echo date("Y") ?> "Sust_ERP" All rights reserved.</p>
    </div>
</footer>