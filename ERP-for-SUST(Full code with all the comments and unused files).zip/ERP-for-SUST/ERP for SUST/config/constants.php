<?php

// First name = 'ERP' Last name = 'SUST'
// Email = erpforsust@gmail.com
// Password = Qwe12345Qwe12345

define('EMAIL', 'erpforsust@gmail.com');
define('PASSWORD', 'Qwe12345Qwe12345');

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');